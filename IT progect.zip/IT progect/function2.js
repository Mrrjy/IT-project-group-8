const unitprice1 = 10;
const unitprice2 = 20;
const unitprice3 = 20;
const unitprice4 = 10;
const unitprice5 = 15;
const unitprice6 = 5;
const unitprice7 = 25;
const unitprice8 = 10;
const unitprice9 = 10;
let counts = [0, 0, 0, 0, 0, 0, 0, 0, 0];

function breakfast() {
  toggle(index)
  add(index)
  minus(index)
  price(unitprice, counts)
}

function lunch(){
  toggle(index)
  add(index)
  minus(index)
  price(unitprice, counts)
}

function allin(){
  toggle(index)
  add(index)
  minus(index)
  price(unitprice, counts)
}

  function toggle(index) {
    document.getElementById("toggleBtn" + index).classList.add("hide");
    document.getElementById("plusBtn" + index).classList.remove("hide");
    document.getElementById("minusBtn" + index).classList.remove("hide");
  }

  function add(index) {
   counts[index - 1]++;
   document.getElementById("count" + index).innerHTML = counts[index - 1];
   if (counts[index - 1] > 0) {
    document.getElementById("minusBtn" + index).classList.remove("hide");
    document.getElementById("count" + index).classList.remove("hide");
   }
  }

  function minus(index) {
   counts[index - 1]--;
   if (counts[index - 1] >= 0) {
    document.getElementById("count" + index).innerHTML = counts[index - 1];
    if (counts[index - 1] === 0) {
     document.getElementById("plusBtn" + index).classList.add("hide");
     document.getElementById("minusBtn" + index).classList.add("hide");
     document.getElementById("toggleBtn" + index).classList.remove("hide");
     document.getElementById("count" + index).classList.add("hide");
    }
   }
  }

  function price(unitprice, counts) {
   let total = 0;
   for (let i = 0; i < unitprice.length; i++) {
    total += unitprice[i] * counts[i];
   }
   return total;
  }

  let totle = document.getElementById("totle");
  totle.addEventListener("click", function() {
   let unitprices = [unitprice1, unitprice2, unitprice3,unitprice4,unitprice5,unitprice6,unitprice7,unitprice8,unitprice9];
   let totalPrice = price(unitprices, counts)*0.9;
   window.alert("Total price: " + totalPrice);
  });



  //Basket

  let order = {"Cola": 0, "fried chicken": 0,"spaghetti": 0,"ice cream": 0,"rice noodles": 0,"pizza":0,"fried egg":0,"pineapple bun": 0,"porridge": 0}


  //Cola
  document.getElementById("toggleBtn1").addEventListener("click", function() {
    order['Cola'] += 1;
});
  document.getElementById("minusBtn1").addEventListener("click", function() {
  if(order['Cola'] > 0) {
      order['Cola'] -= 1;
  }
});
document.getElementById("plusBtn1").addEventListener("click", function() {
  order['Cola'] += 1;
});

  //fried chicken
  document.getElementById("toggleBtn2").addEventListener("click", function() {
    order['fried chicken'] += 1;
});
  document.getElementById("minusBtn2").addEventListener("click", function() {
  if(order['fried chicken'] > 0) {
      order['fried chicken'] -= 1;
  }
});
document.getElementById("plusBtn2").addEventListener("click", function() {
  order['fried chicken'] += 1;
});


  //spaghetti
  document.getElementById("toggleBtn3").addEventListener("click", function() {
    order['spaghetti'] += 1;
});
  document.getElementById("minusBtn3").addEventListener("click", function() {
  if(order['spaghetti'] > 0) {
      order['spaghetti'] -= 1;
  }
});
document.getElementById("plusBtn3").addEventListener("click", function() {
  order['spaghetti'] += 1;
});

  //ice cream
  document.getElementById("toggleBtn9").addEventListener("click", function() {
    order['ice cream'] += 1;
});
  document.getElementById("minusBtn9").addEventListener("click", function() {
  if(order['ice cream'] > 0) {
      order['ice cream'] -= 1;
  }
});
document.getElementById("plusBtn9").addEventListener("click", function() {
  order['ice cream'] += 1;
});


  //rice noodles
  document.getElementById("toggleBtn8").addEventListener("click", function() {
    order['rice noodles'] += 1;
});
  document.getElementById("minusBtn8").addEventListener("click", function() {
  if(order['rice noodles'] > 0) {
      order['rice noodles'] -= 1;
  }
});
document.getElementById("plusBtn8").addEventListener("click", function() {
  order['rice noodles'] += 1;
});



  //pizza
  document.getElementById("toggleBtn7").addEventListener("click", function() {
    order['pizza'] += 1;
});
  document.getElementById("minusBtn7").addEventListener("click", function() {
  if(order['pizza'] > 0) {
      order['pizza'] -= 1;
  }
});
document.getElementById("plusBtn7").addEventListener("click", function() {
  order['pizza'] += 1;
});


  //fried egg
  document.getElementById("toggleBtn6").addEventListener("click", function() {
    order['fried egg'] += 1;
});
  document.getElementById("minusBtn6").addEventListener("click", function() {
  if(order['fried egg'] > 0) {
      order['fried egg'] -= 1;
  }
});
document.getElementById("plusBtn6").addEventListener("click", function() {
  order['fried egg'] += 1;
});


  //pineapple bun
  document.getElementById("toggleBtn5").addEventListener("click", function() {
    order['pineapple bun'] += 1;
});
  document.getElementById("minusBtn5").addEventListener("click", function() {
  if(order['pineapple bun'] > 0) {
      order['pineapple bun'] -= 1;
  }
});
document.getElementById("plusBtn5").addEventListener("click", function() {
  order['pineapple bun'] += 1;
});


  //porridge
  document.getElementById("toggleBtn4").addEventListener("click", function() {
    order['porridge'] += 1;
});
  document.getElementById("minusBtn4").addEventListener("click", function() {
  if(order['porridge'] > 0) {
      order['porridge'] -= 1;
  }
});
document.getElementById("plusBtn4").addEventListener("click", function() {
  order['porridge'] += 1;
});




document.getElementById("basket").addEventListener("click", function() {
  let message = "";
  for (let item in order) {

      if(order[item] > 0) {
          message += item + " quantity: " + order[item] + "\n";
      }
  }
  if(message === "") {
      alert("Your order is empty");
  } else {
      alert(message);
  }
})


